char billing(void);
char delete(void);

