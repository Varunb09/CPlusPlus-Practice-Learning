void delay(int c);
void command(int c);
void data(char c );
void data1(char c[] );
void lcd(void);
void lcd_string(char *str);
void display(int c);
